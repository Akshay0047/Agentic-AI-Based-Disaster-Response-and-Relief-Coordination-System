# Overnight Log — Disaster Response Coordinator

Working session log. Each phase lists what was done, assumptions, deviations, and the exact verification commands.

---

## Phase 1 — Login 500 fix + migration 0002 verification ✅

### Bug A: Migration 0002 enum backfill (carried over, verified fixed)
- `0002_add_ai_reasoning_and_timestamps.py` backfilled `availability_status` with `CASE WHEN availability THEN 'available' ELSE 'unavailable' END` — Postgres returns text from CASE and refuses the implicit cast into the enum column.
- Fix: explicit casts on every branch — `'available'::availability_status` / `'unavailable'::availability_status`.

### Bug B: revision id too long for `alembic_version.version_num` (varchar(32))
- Found while rerunning: `0002_add_ai_reasoning_and_timestamps` is 37 chars → `StringDataRightTruncation` when stamping the version table. Every prior attempt rolled back cleanly (transactional DDL), so the DB was verified empty — no partial state (`alembic_version` didn't even exist).
- Fix: shortened revision id to `0002_ai_reasoning_and_timestamps` (32 chars, fits exactly) and renamed the file to match. Updated the docstring `Revision ID:` line too.
- **Deviation from spec:** revision is now `0002_ai_reasoning_and_timestamps`, not `0002_add_ai_reasoning_and_timestamps`. `alembic current` reports it as head (pasted below).

### Bug C: THE login 500 — mapper misconfiguration, not password hashing
- Suspects from the brief were both innocent: `create_access_token` already does `str(subject)` (jwt payload is fine), and the seeded hashes verify cleanly with `verify_password` (checked directly: `seedcheck: True`).
- Real root cause (traceback captured from `uvicorn_err.log`): `sqlalchemy.exc.InvalidRequestError: When initializing mapper Mapper[User(users)], expression 'AgentActionLog.approved_by' failed to locate a name`. `User.approved_actions` is a string-identified relationship to `AgentActionLog`; `app.main` only imported route modules, which import `User` — but nothing at app startup imported `app.db.base`, so `AgentActionLog` was never registered and the first ORM query in `authenticate()` blew up during mapper configuration.
- Fix: `import app.db.base  # noqa: F401` at the top of `api-service/app/main.py`.

### Safety nets added (tests/test_api.py)
- `test_all_models_configure_cleanly` — imports `app.db.base` and calls `sqlalchemy.orm.configure_mappers()`; any future unresolvable string relationship fails loudly here instead of 500ing at runtime.
- `test_login_success_volunteer`, `test_login_success_admin` — positive login tests asserting 200, `token_type == "bearer"`, 3-segment JWT, correct role.
- `test_login_wrong_password_rejected` — 401 on bad password.

### Test-harness fix (conftest.py)
- First full pytest run: 5 passed / 8 failed — all failures were Windows asyncpg cross-event-loop pool corruption (`'NoneType' object has no attribute 'send'`, `Event loop is closed`), not app bugs. Cause: the shared pooled engine hands connections bound to one loop (truncate fixture / TestClient portal / `asyncio.run`) to another.
- Fix: conftest now builds a `NullPool` engine and patches `app.db.session.engine` / `AsyncSessionLocal` for the test session. App code untouched.

### Seed change
- Added admin `admin@example.com` / `password123` (bcrypt via the same `hash_password()` used by the app) to `app/scripts/seed.py`.

### Verification (live, Invoke-RestMethod against real uvicorn + Docker Postgres)
- `alembic current` → `0002_ai_reasoning_and_timestamps (head)`
- `POST /api/v1/auth/login` vol1@example.com → 200, real JWT, role volunteer
- `POST /api/v1/auth/login` admin@example.com → 200, real JWT, role admin
- `GET /api/v1/volunteers` (admin) → 200, 4 volunteers with `availability_status` enum values + `current_workload`
- `PATCH /api/v1/volunteers/{id}/availability` → 200, `busy` persisted (re-GET confirms)
- `\d+ volunteers` → `availability_status availability_status` NOT NULL, `current_workload integer NOT NULL DEFAULT 0`, index `ix_volunteers_availability_status`
- pytest: **13 passed** in 38.27s

### Process note
- `Start-Job`/hidden `Start-Process` from tool calls is unreliable (jobs die with the shell, sleeps time out). Live verification is done in a single self-contained command: start uvicorn → poll /docs → exercise endpoints → stop process. Uvicorn log temp files written to `%TEMP%`, stray repo-root logs deleted.

---

## Phase 2 — CRUD completeness + simulation data generator — IN PROGRESS
